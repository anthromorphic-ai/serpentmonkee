import time


class Serpent:
    def __init__(self, someText):
        self.txt = someText
        print('Serpent: {}'.format(self.txt))
